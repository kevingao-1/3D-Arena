# 3D World Test Game

A lightweight 3D game engine built with Three.js and vanilla JavaScript.

## Features

- Three.js-based 3D rendering with WebGL
- First-person camera with mouse look
- Scene and entity management
- Input handling (keyboard + mouse)
- Physics (gravity, jumping, collisions)
- Example game included

## Run

1. Open `index.html` in your browser.
2. Click on the game area to lock the pointer.
3. Use WASD to move, Space to jump, mouse to look around.

## Files

- `index.html` — entry point with Three.js CDN
- `style.css` — layout and container styling
- `src/engine.js` — 3D engine core with Three.js integration
- `src/game.js` — example 3D game logic with Perlin noise block terrain
